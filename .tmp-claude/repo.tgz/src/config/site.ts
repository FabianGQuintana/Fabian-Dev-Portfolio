import type { Locale } from "@/i18n/routing";

/**
 * Configuracion global del sitio.
 *
 * Todo dato que se repita en mas de un lugar (nombre, URLs, redes) vive aqui.
 * Los textos traducibles NO: esos van en src/messages/, resueltos por
 * next-intl.
 */

const GITHUB_URL = "https://github.com/FabianGQuintana";
const LINKEDIN_URL = "https://www.linkedin.com/in/fabian-quintana-60a59a325";

export const siteConfig = {
  name: "Fabian Quintana",
  /** Iniciales para el logo del header y el avatar de placeholder. */
  monogram: "FQ",
  role: "AI-Augmented Software Developer",

  /**
   * Tagline del Hero (Opcion A del plan).
   * Se mantiene aqui y no en messages/ porque tambien alimenta la metadata
   * del sitio (description por locale), fuera del arbol de traducciones de UI.
   */
  tagline: {
    es: "Diseño la base de datos, construyo la API y pulo la interfaz. Sistemas completos",
    en: "I design the database, build the API and refine the interface. Complete systems",
  } satisfies Record<Locale, string>,

  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",

  github: {
    username: "FabianGQuintana",
    url: GITHUB_URL,
  },

  links: {
    linkedin: LINKEDIN_URL,
    email: "quintanafabiangustavo@gmail.com",
  },

  /**
   * Secuencia del teclado 3D del hero: cada palabra se teclea y, al pulsar
   * Enter, emerge su icono clickeable. El orden del array es el orden de
   * tecleo. Un href que empieza con "#" hace scroll a esa seccion.
   */
  heroSocials: [
    { id: "github", word: "GITHUB", href: GITHUB_URL },
    {
      id: "linkedin",
      word: "LINKEDIN",
      href: LINKEDIN_URL,
    },
    { id: "gmail", word: "GMAIL", href: "#contact" },
  ],

  /**
   * CV.
   * `enabled: false` renderiza el boton en estado deshabilitado con tooltip.
   * Hoy existe una sola version (en espanol) y se sirve en ambos locales.
   */
  resume: {
    enabled: true,
    path: "/cv/fabian-quintana-cv.pdf",
  },
} as const;

export type SiteConfig = typeof siteConfig;
