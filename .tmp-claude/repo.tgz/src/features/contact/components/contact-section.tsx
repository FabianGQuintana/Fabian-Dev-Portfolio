import { getTranslations } from "next-intl/server";

import { ScrollRevealHeading } from "@/components/motion";

import { ContactExperience } from "./contact-experience";

import type { ContactUiLabels } from "../types";

/**
 * Seccion de contacto.
 *
 * Server Component: resuelve las traducciones y se las pasa al formulario
 * cliente. El form no llama a `getTranslations` porque es un Client
 * Component; las labels viajan como datos ya traducidos.
 */
export async function ContactSection() {
  const t = await getTranslations("contact");

  const labels: ContactUiLabels = {
    name: t("name"),
    email: t("email"),
    subject: t("subject"),
    message: t("message"),
    send: t("send"),
    sending: t("sending"),
    success: t("success"),
    error: t("error"),
    errorRateLimited: t("error_rate_limited"),
    errors: {
      name_short: t("errors.name_short"),
      email_invalid: t("errors.email_invalid"),
      subject_short: t("errors.subject_short"),
      message_short: t("errors.message_short"),
      website: t("errors.website"),
    },
  };

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="relative z-10 container-section py-[clamp(80px,12vh,160px)]"
    >
      <ScrollRevealHeading id="contact-heading" text={t("title")} />

      <ContactExperience labels={labels} />
    </section>
  );
}
